from flask import Flask, render_template, request, redirect, url_for, session
from blockchain_utils import add_certificate, verify_certificate
from crypto_utils import encrypt_certificate, decrypt_certificate
import uuid
import os
import qrcode
from database import init_db, add_user, verify_user
from crypto_utils import decrypt_data
from datetime import timedelta

app = Flask(__name__)
app.secret_key = '98fa0f4967df05883d79913b8fe48a29599a7b8066153d13' #flask_secretkey

# Set the session timeout to 15 minutes
app.permanent_session_lifetime = timedelta(minutes=15)

# Initialize the database
init_db()

# Create the 'static/qr_codes' directory if don't exist
if not os.path.exists('static/qr_codes'):
    os.makedirs('static/qr_codes')

@app.route("/")
def index():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return render_template("index.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form['username']
        password = request.form['password']
        if verify_user(username, password):
            session.permanent = True  # Ensures the session is permanent (to apply timeout)
            session['username'] = username
            return redirect(url_for('dashboard'))
        else:
            return "Login failed. Please check your username and password."
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form['username']
        password = request.form['password']
        try:
            add_user(username, password)
            return redirect(url_for('login'))
        except Exception as e:
            return "An error occurred while registering. Please try again."
    return render_template("register.html")

@app.route("/logout")
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

@app.route("/dashboard")
def dashboard():
    if 'username' in session:
        return render_template("dashboard.html")
    return redirect(url_for('login'))

@app.route("/add", methods=["GET"])
def add():
    if 'username' in session:
        return render_template("add.html")
    return redirect(url_for('login'))

@app.route("/add_certificate", methods=["POST"])
def add_certificate_route():
    if 'username' in session:
        certificate_data = {
            'university': request.form['university'],
            'department': request.form['department'],
            'studentname': request.form['student_name'],
            'academicyear': request.form['academic_year'],
            'regnum': request.form['regnum'],
            'joiningdate': request.form['joining_date'],
            'enddate': request.form['end_date'],
            'CGPA': request.form['CGPA']
        }

        cert_id = str(uuid.uuid4())

        try:
            # Encrypt the certificate data
            encrypted_data = encrypt_certificate(certificate_data)

            tx_hash = add_certificate(
                cert_id,
                encrypted_data['university'],
                encrypted_data['studentname'],
                encrypted_data['department'],
                encrypted_data['academicyear'],
                encrypted_data['regnum'],
                encrypted_data['joiningdate'],
                encrypted_data['enddate'],
                encrypted_data['CGPA']
            )

            # Generate QR code for the certificate
            qr_data = f'http://localhost:5000/verify?keyId={cert_id}'
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(qr_data)
            qr.make(fit=True)
            qr_img = qr.make_image(fill='black', back_color='white')

            # Save QR code image
            qr_code_filename = f'{cert_id}.png'
            qr_code_path = os.path.join('static/qr_codes', qr_code_filename)
            qr_img.save(qr_code_path)

            # Render success template with UUID and QR code filename
            return render_template('add_success.html', cert_id=cert_id, qr_code_filename=qr_code_filename)

        except Exception as e:
            return "An unexpected error occurred while adding the certificate. Please try again later."
    return redirect(url_for('login'))

@app.route("/verify", methods=["GET", "POST"])
def verify():
    if request.method == "POST":
        cert_id = request.form.get("keyId")
    elif request.method == "GET":
        cert_id = request.args.get("keyId")
    else:
        return render_template('verify.html')

    if cert_id:
        print(f"Verifying certificate with ID: {cert_id}")
        raw_cert_data = verify_certificate(cert_id)
        print(f"Raw certificate data: {raw_cert_data}")
        
        if raw_cert_data and len(raw_cert_data) >= 8:
            try:
                # Process the raw data
                cert = {
                    "university": raw_cert_data[0],
                    "studentname": raw_cert_data[1],
                    "department": raw_cert_data[2],
                    "academicyear": raw_cert_data[3],
                    "regnum": raw_cert_data[4],
                    "joiningdate": raw_cert_data[5],
                    "enddate": raw_cert_data[6],
                    "CGPA": raw_cert_data[7]
                }
                
                # Try to decrypt each field
                decrypted_cert = {}
                for key, value in cert.items():
                    try:
                        decrypted_cert[key] = decrypt_data(value)
                        print(f"Decrypted {key}: {decrypted_cert[key]}")
                    except Exception as e:
                        print(f"Error decrypting {key}: {str(e)}")
                        decrypted_cert[key] = value  # Use original value if decryption fails
                
                return render_template('success.html', 
                                       keyId=cert_id, 
                                       university=decrypted_cert.get('university'),
                                       department=decrypted_cert.get('department'), 
                                       studentname=decrypted_cert.get('studentname'), 
                                       academicyear=decrypted_cert.get('academicyear'), 
                                       regnum=decrypted_cert.get('regnum'), 
                                       joiningdate=decrypted_cert.get('joiningdate'), 
                                       enddate=decrypted_cert.get('enddate'), 
                                       CGPA=decrypted_cert.get('CGPA'))
            except Exception as e:
                print(f"Error processing certificate data: {str(e)}")
                return render_template('fraud.html', message="We encountered an issue processing this certificate. Please contact support.")
        else:
            print("No valid certificate data returned from blockchain")
            return render_template('fraud.html', message="The certificate could not be authenticated. Please check the UUID and try again.")
    return render_template('verify.html')

if __name__ == "__main__":
    app.run(debug=True)
