from web3 import Web3
from dotenv import load_dotenv
import json
import uuid
import os
from web3.exceptions import ContractLogicError

# Load environment variables from .env file
load_dotenv()

# Connect to the Sepolia network
infura_url = os.getenv('INFURA_URL')
web3 = Web3(Web3.HTTPProvider(infura_url))

# Ensure connection is established
if not web3.is_connected():
    raise ConnectionError("Failed to connect to Ethereum network")

# Contract address and ABI
contract_address = Web3.to_checksum_address(os.getenv('CONTRACT_ADDRESS'))
abi = json.loads('''
[
    {
        "inputs": [
            {"internalType": "string", "name": "_id", "type": "string"},
            {"internalType": "string", "name": "_university", "type": "string"},
            {"internalType": "string", "name": "_studentName", "type": "string"},
            {"internalType": "string", "name": "_department", "type": "string"},
            {"internalType": "string", "name": "_academicYear", "type": "string"},
            {"internalType": "string", "name": "_regnum", "type": "string"},
            {"internalType": "string", "name": "_joiningDate", "type": "string"},
            {"internalType": "string", "name": "_endDate", "type": "string"},
            {"internalType": "string", "name": "_CGPA", "type": "string"}
        ],
        "name": "addCertificate",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {"internalType": "string", "name": "_id", "type": "string"}
        ],
        "name": "getCertificate",
        "outputs": [
            {"internalType": "string", "name": "university", "type": "string"},
            {"internalType": "string", "name": "studentName", "type": "string"},
            {"internalType": "string", "name": "department", "type": "string"},
            {"internalType": "string", "name": "academicYear", "type": "string"},
            {"internalType": "string", "name": "regnum", "type": "string"},
            {"internalType": "string", "name": "joiningDate", "type": "string"},
            {"internalType": "string", "name": "endDate", "type": "string"},
            {"internalType": "string", "name": "CGPA", "type": "string"},
            {"internalType": "uint256", "name": "timestamp", "type": "uint256"}
        ],
        "stateMutability": "view",
        "type": "function"
    }
]
''')

contract = web3.eth.contract(address=contract_address, abi=abi)

def add_certificate(id, university, student_name, department, academic_year, regnum, joining_date, end_date, CGPA):
    try:
        web3.eth.default_account = os.getenv('DEFAULT_ACCOUNT')
        private_key = os.getenv('PRIVATE_KEY')

        # Fetch the current nonce
        nonce = web3.eth.get_transaction_count(web3.eth.default_account)

        # Fetch the current gas price
        gas_price = web3.eth.gas_price
        
        # Estimate gas
        gas_estimate = contract.functions.addCertificate(
            id, university, student_name, department, academic_year, regnum, joining_date, end_date, CGPA
        ).estimate_gas({'from': web3.eth.default_account})

        # Increase gas price to be higher than previous transactions
        gas_price = int(gas_price * 1.1)  # Increase by 10% to ensure it's higher than any pending transaction

        # Build transaction
        tx = contract.functions.addCertificate(
            id, university, student_name, department, academic_year, regnum, joining_date, end_date, CGPA
        ).build_transaction({
            'chainId': 11155111,
            'gas': gas_estimate + 10000,  # Add a bit of extra gas
            'gasPrice': gas_price,
            'nonce': nonce,
        })

        # Sign the transaction
        signed_tx = web3.eth.account.sign_transaction(tx, private_key=private_key)
        
        # Send the transaction
        tx_hash = web3.eth.send_raw_transaction(signed_tx.rawTransaction)
        tx_hash_hex = tx_hash.hex()

        # Wait for the transaction receipt
        receipt = web3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)

        if receipt['status'] == 1:
            return tx_hash_hex
        else:
            raise Exception("Transaction failed")
    except Exception as e:
        print(f"Error adding certificate: {e}")
        raise

def verify_certificate(certificate_id):
    try:
        print(f"Attempting to verify certificate with ID: {certificate_id}")
        # Fetch certificate details from the smart contract
        result = contract.functions.getCertificate(certificate_id).call()
        print(f"Raw result from blockchain: {result}")
        
        # Return the raw result without processing
        return result
    except ContractLogicError as e:
        print(f"Contract logic error: {e}")
        return None
    except Exception as e:
        print(f"Unexpected error verifying certificate: {e}")
        raise

