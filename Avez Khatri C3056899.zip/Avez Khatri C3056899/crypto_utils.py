from cryptography.fernet import Fernet, InvalidToken
import os
from dotenv import load_dotenv
import logging

# Set up logging
logging.basicConfig(level=logging.ERROR)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Get the encryption key from the environment variable
ENCRYPTION_KEY = os.getenv('ENCRYPTION_KEY')

# Create a Fernet instance
fernet = Fernet(ENCRYPTION_KEY.encode())

def encrypt_data(data: str) -> str:
    """Encrypt a string."""
    try:
        return fernet.encrypt(data.encode()).decode()
    except Exception as e:
        logger.error(f"Encryption error: {str(e)}")
        raise ValueError("An error occurred during encryption.")

def decrypt_data(encrypted_data: str) -> str:
    """Decrypt an encrypted string."""
    try:
        return fernet.decrypt(encrypted_data.encode()).decode()
    except InvalidToken:
        logger.error("Invalid token error during decryption")
        return "[Decryption Error]"
    except Exception as e:
        logger.error(f"Decryption error: {str(e)}")
        return "[Decryption Error]"

def encrypt_certificate(certificate: dict) -> dict:
    """Encrypt all fields of a certificate."""
    try:
        return {key: encrypt_data(str(value)) for key, value in certificate.items()}
    except Exception as e:
        logger.error(f"Certificate encryption error: {str(e)}")
        raise ValueError("An error occurred while encrypting the certificate.")

def decrypt_certificate(encrypted_certificate: dict) -> dict:
    """Decrypt all fields of an encrypted certificate."""
    return {key: decrypt_data(value) for key, value in encrypted_certificate.items()}