import os
secret_key = os.urandom(24)
print(f"Generated secret key: {secret_key.hex()}")
